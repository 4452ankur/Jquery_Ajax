﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;


namespace Jquery.JqueryEx
{
    public partial class WebForm2 : System.Web.UI.Page
    {
       // public List<Product> products;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                BindColumnToGridview();
            }
        }
        /// <summary>
        /// This method is used to bind dummy row to gridview to bind data using JQuery
        /// </summary>
        private void BindColumnToGridview()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Category");
            dt.Columns.Add("Price");
            dt.Columns.Add("ProductName");
            dt.Rows.Add();
            gvDetails.DataSource = dt;
            gvDetails.DataBind();
            gvDetails.Rows[0].Visible = false;
            //gvDetails.Visible = false;
        }
        [WebMethod]
        public static string Bindtable1(string ank)
        {
            List<Product> details = new List<Product>();
            List<Product> pdetails = new List<Product>();
            pdetails.Add(new Product() { Category = "computers", Price = 200, ProductName = "Dell PC" });
            pdetails.Add(new Product() { Category = "shoes", Price = 90, ProductName = "Nike" });
            pdetails.Add(new Product() { Category = "shoes", Price = 66, ProductName = "Adidas" });
            pdetails.Add(new Product() { Category = "computers", Price = 210, ProductName = "HP PC" });
            pdetails.Add(new Product() { Category = "shoes", Price = 85, ProductName = "Puma" });

            details.AddRange(pdetails.Where(x => x.Category == ank));

            return ank;
        } 

        [WebMethod]
        public static Product[] Bindtable(string category)
        {
            List<Product> details = new List<Product>();
            List<Product> pdetails = new List<Product>();
            pdetails.Add(new Product() { Category = "computers", Price = 200, ProductName = "Dell PC" });
            pdetails.Add(new Product() { Category = "shoes", Price = 90, ProductName = "Nike" });
            pdetails.Add(new Product() { Category = "shoes", Price = 66, ProductName = "Adidas" });
            pdetails.Add(new Product() { Category = "computers", Price = 210, ProductName = "HP PC" });
            pdetails.Add(new Product() { Category = "shoes", Price = 85, ProductName = "Puma" });

            details.AddRange(pdetails.Where(x=>x.Category== category));
        
            return details.ToArray();
        }
        [System.Web.Services.WebMethod()]
        // IMPORTANT: pass the paramenter with POST and data 
        public static string TestParPost(string id)
        {
            return " parametro: " + id.ToString();
        }
    }

    //load sample data method
    //public void LoadSampleProductsData(string category)
    //{

    //    products = new List<Product>();
    //    products.Add(new Product() { Category = "computers", Price = 200, ProductName = "Dell PC" });
    //    products.Add(new Product() { Category = "shoes", Price = 90, ProductName = "Nike" });
    //    products.Add(new Product() { Category = "shoes", Price = 66, ProductName = "Adidas" });
    //    products.Add(new Product() { Category = "computers", Price = 210, ProductName = "HP PC" });
    //    products.Add(new Product() { Category = "shoes", Price = 85, ProductName = "Puma" });
    //    DataTable dt = new DataTable();
    //    dt=products.Where(x => x.Category == category);
    //    Repeater1.DataSource = products.Where(x => x.Category == category);
    //    Repeater1.DataBind(); //bind repeater
    //}


}


    public class Product
    {
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public string Category { get; set; }

    }
