﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Services;
using System.Web.Script.Services;

namespace Jquery.JqueryEx
{
    public partial class jQueryAJAX : System.Web.UI.Page
    {
        // First we need to populate an empty row in GridView.
        //Reason behind this is if we didn’t assign any datasource then the GridView won’t populate at runtime and we won’t be able to access it at client side.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindColumnToGridview();
                BindDropdown();
            }


        }
       // https://www.aspsnippets.com/Articles/Populate-ASPNet-Repeater-by-binding-DataSet-Client-Side-using-jQuery-AJAX.aspx
        private void BindColumnToGridview()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Category");
            dt.Columns.Add("Price");
            dt.Columns.Add("ProductName");
            dt.Rows.Add();
            gvDetails.DataSource = dt;
            gvDetails.DataBind();
            gvDetails.Rows[0].Visible = false;
            //gvDetails.Visible = false;
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("priority_id");
            dt1.Columns.Add("token_id");
            dt1.Columns.Add("prob_summary");
            dt1.Columns.Add("prob_date");
         
            dt1.Rows.Add();
            grvDbase.DataSource = dt1;
            grvDbase.DataBind();
            grvDbase.Rows[0].Visible = false;


        }
        private void BindDropdown() {
            string Constr = ConfigurationManager.ConnectionStrings["Con_ItInfra"].ConnectionString;
            SqlConnection con = new SqlConnection(Constr);
            SqlCommand cmd = new SqlCommand();
            SqlDataReader SqlReader;


            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_view_priority";
            cmd.Connection = con;
            con.Open();


            SqlReader = cmd.ExecuteReader();
            ddlLst.DataSource = SqlReader;
            ddlLst.DataTextField = "priority_id";
            ddlLst.DataValueField = "priority_id";

            ddlLst.DataBind();
            con.Close();

        }
        //https://www.aspsnippets.com/Articles/Populate-ASPNet-Repeater-by-binding-DataSet-Client-Side-using-jQuery-AJAX.aspx
        [WebMethod]
        public static Product1[] Bindtable(string category)
        {
            List<Product1> details = new List<Product1>();
            List<Product1> pdetails = new List<Product1>();
            pdetails.Add(new Product1() { Category = "computers", Price = 200, ProductName = "Dell PC" });
            pdetails.Add(new Product1() { Category = "shoes", Price = 90, ProductName = "Nike" });
            pdetails.Add(new Product1() { Category = "shoes", Price = 66, ProductName = "Adidas" });
            pdetails.Add(new Product1() { Category = "computers", Price = 210, ProductName = "HP PC" });
            pdetails.Add(new Product1() { Category = "shoes", Price = 85, ProductName = "Puma" });

         details.AddRange(pdetails.Where(x => x.Category == category));
          
            return details.ToArray();

            
        }
        [WebMethod]
        public static Prob_master[] DbaseBind(string priority_id)
        {
            DataTable dt = new DataTable();
      
            string DbCon = ConfigurationManager.ConnectionStrings["Con_ItInfra"].ConnectionString;
            SqlConnection sqlcon = new SqlConnection(DbCon);
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter sqlAdp = new SqlDataAdapter();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_sidplay_prob_master";
            cmd.Parameters.Add("@priority_id", SqlDbType.NVarChar).Value = priority_id;
           
            cmd.Connection = sqlcon;
            sqlAdp.SelectCommand = cmd;
            sqlcon.Open();
            sqlAdp.Fill(dt);
            sqlcon.Close();
            List<Prob_master> pmaster = new List<Prob_master>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];
                // do something with dr
                pmaster.Add(new Prob_master() { priority_id = dr["priority_id"].ToString(), token_id = dr["token_id"].ToString(), prob_summary = dr["prob_summary"].ToString(), prob_date = dr["prob_date"].ToString() });

            }
            return pmaster.ToArray();

        }

        //https://andrearegoli.wordpress.com/2015/09/17/ajax-web-method-in-asp-net-page/
       // https://stackoverflow.com/questions/10750631/calling-a-webmethod-using-jqueryajax-get
        [WebMethod]
        [ScriptMethod(UseHttpGet = true)]
        public static string testGet()
        {
            return "Ayushmaan Bhattacharya";
        }
        [WebMethod]
        [ScriptMethod(UseHttpGet =true)]
        public static dynamic testGetClass()
        {
            return new { Name = "Ankur", age = 12 };
        }




    }




    public class Product1
    {
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public string Category { get; set; }

    }

    public class Prob_master
    {
        public string priority_id { get; set; }
            public string token_id { get; set; }
            public string prob_summary { get; set; }
            public string prob_date { get; set; }
    }
}