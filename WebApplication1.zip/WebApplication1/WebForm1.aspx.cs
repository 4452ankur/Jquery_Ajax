﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [System.Web.Services.WebMethod()]
        // IMPORTANT: pass the paramenter with POST and data 
        public static string TestParPost(int id)
        {
             return " parametro: " + id.ToString();
        }
    }
}